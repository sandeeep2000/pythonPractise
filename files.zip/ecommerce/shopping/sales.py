# print("sales initialised", __name__)


def calc_tax():
    pass


def calc_shipping():
    pass


if __name__ == "__main__":
    print("sales started")
    calc_tax()
